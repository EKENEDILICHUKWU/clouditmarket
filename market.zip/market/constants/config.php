<?php
//Website Settings
$site_title = "CLOUDIT MARKET PLACE";
$about_site = "A free classified ads website for Cars, Phones, Electronics, Smartphones, Real estate, Farm products and everything else. Find what you're looking for or create your own ad for free!.";

date_default_timezone_set('Africa/Dar_es_salaam');

$currency = "NGN/=";
$installation_path = "localhost/market";


//Social Network Setings
$facebook_link = "#";
$twitter_link = "#";
$instagram_link = "#";
$googleplus_link = "#";

//Database Settings
$servername = "localhost";
$username = "cloudite_classmarket";
$password = "@#123@#uniben";
$dbname = "cloudite_classmarket";

//Contact Settings
$site_email = "cloudit.etutors@gmail.com";
$site_phone = "+234 90 9365 0089";
$site_address = "Shop A16 University of Benin Teaching Hospital, Shoping Complex";

//SMTP Settings
$smtp_host = '';
$smtp_user = '';
$smtp_pass = '';




?>